---------------------------------------------------------------
Ejercicio sobre analítica y visualización de datos con Power BI
Autoras:
	María Barroso Honrubia
	Gloria del Valle Cano

---------------------------------------------------------------

* p4_gd_barroso_valle.ipynb: se encuentran las tranformaciones realizadas para manipular los datos del informe
* informe_covid.pdf: primera página del informe exportado en Power BI
* informe_covid.pptx: presentación PowerPoint del informe
* informe_covid.jpeg: captura de pantalla del informe desde Power BI (ya que al exportar los colores se cambian un poco)
* data: contiene los datos utilizados para el análisis